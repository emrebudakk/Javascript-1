


console.log("Toplam:", 123*145);