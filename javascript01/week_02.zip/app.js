
/*
1) butona basildiginda olay halledici cagrilir
2) Verilen sayi kadar daire body'ye otomatik olarak eklenir
2.1) Balonlarin yaricaplari rastgele secilir
2.2) Balonlarin renkleri rastgele secilir
2.3) Balonlarin pozisyonlari rastgele secilir.
*/

// dom agacinda hali hazirda olusturulmus olan BUTON nesnesine ulas
const button = document.querySelector("#trigger-animation");
const toplamBalonSayisi = 10; 
const body = document.body;


// butona dinleyici ekle
button.addEventListener("click", function(){
    
    for(let sayac=0; sayac<100; sayac = sayac + 2 ){
        const div = document.createElement("div");
        const cap = Math.floor(Math.random() * 100) + 30;
        const randomColor = '#'+Math.floor(Math.random()*16777215).toString(16);
        const topPozisyon = Math.floor(Math.random() * 600);
        const leftPozisyon = Math.floor(Math.random() * 600);
    
        div.style.left = leftPozisyon + "px";
        div.style.top = topPozisyon + "px";
        div.style.backgroundColor = randomColor;
        div.style.borderRadius = (cap/2) + "px";
        div.style.width = cap + "px";
        div.style.height = cap + "px";
    
        body.appendChild(div);
    }
})