
/*
1) butonun bir olay dinleyici dinlanilmesi gerceklestirilir
2) butonun dinleyicisine olay halledicisi ekliyorum.
2.1) main elamanina "animation" classinin eklenmesini/cikarilmasini gerceklestiriyorum.
*/

// dom agacinda hali hazirda olusturulmus olan BUTON nesnesine ulas
const button = document.querySelector("#trigger-animation");


// butona dinleyici ekle
button.addEventListener("click", function(){
    
    // domdaki main elemanina ulas
    const main = document.querySelector("#container");

    // main tagine "animation" classini ekle
    main.classList.toggle("animation");

    const randomNumber = Math.floor(Math.random() * 10);
    const randomNumberContainer = document.querySelector("#random-number");
    randomNumberContainer.innerHTML = randomNumber;
})